import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: require('./assets/iiiiiiddddddkkkkooooo.jpg'),
    name: 'Jalbay Jerove B.',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Buenavista Elementary School',
      elementaryYear: '2014',
      highSchool: 'Dagohoy National High School',
      highSchoolYear: '2017',
      seniorSchool: 'Dagohoy National High School',
      seniorSchoolYear: '2019',
      college: 'Global Reciprocal Colleges',
      collegeYear: '2021',
    },

    about: `I am currently taking a Bachelor of Scince in Information Technology in 9th Avenue Caloocan City. Im a kind of a persomn willing to learn and enhance my knowledge more. While I'm just starting out, I'm eager to dive into the world of technology and learn all about programming, networking, cybersecurity, and everything else this exciting field has to offer. I'm ready to embrace the challenges, absorb knowledge like a sponge, and eventually become a proficient IT professional. Looking forward to the adventure ahead!`,
   
   
    projects:
      {
        projectName: ' Tree Planting',
        imageSrc: 'https://scontent.fmnl33-3.fna.fbcdn.net/v/t1.15752-9/423735659_263403710179945_4229330181592743435_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeEKlnLUqbStCsBf1UhHFfXV0lcm1QeJ4mTSVybVB4niZDAETWL4JCDh4uQhvjGOwBphAHiqQTMrlRXIgQQEJA9T&_nc_ohc=rYyp3-dw4K4AX8a1NwP&_nc_ht=scontent.fmnl33-3.fna&oh=03_AdS3Qv1JOQmHpc7JCpoOaGBl4QbFLg1XfLfEy-HUX1Gatg&oe=65FD535A',
        description: '"Hey everyone! 🌳 Lets make our planet greener, one tree at a time! Join us for a tree planting event this weekend and lets contribute to a healthier environment together. Every tree we plant today is a gift to future generations. See you there! 🌱 #PlantTrees #GoGreen.',
      },

    contact: {
      mobile: '09677-162-527',
      email: 'jerovebonjayag@gmail.com / jalbayjerove@gmail.com', 
    },
  };

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
        return 'education';
      case 'education':
        return 'about';
      case 'about':
        return 'projects';
      case 'projects':
          return 'contact'; 
        case 'contact':
          return 'name'; 
        default:
          return 'name';
    }
  });
};

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.college}</Text>
                {' | '}
                {resumeData.education.collegeYear}
           
              <Text style={styles.projectTitle}>
                {'\n'}High School:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.highSchool}</Text>
                {' | '}
                {resumeData.education.highSchoolYear}
     
              <Text style={styles.projectTitle}>
                {'\n'}Elementary:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.elementary}</Text>
                {' | '}
                {resumeData.education.elementaryYear}
           
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>About me:{'\n'}</Text>
              <Text style={styles.about}>{resumeData.about}</Text>
            </View>
          )}

{currentSection === 'projects' && (
  <View style={styles.projectsContainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
    <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
    <Text style={styles.projectDescription}> {resumeData.projects.description}</Text>
  </View>
)}

          {currentSection === 'contact' && (
            <View style={styles.contactContainer}>
              <Text style={styles.header1}>Contact Me:{'\n'}</Text>
              <Text style={styles.info1}>
                {'\n'}Mobile: {resumeData.contact.mobile}
                {'\n'}Email: {resumeData.contact.email}
              </Text>
            </View>
          )}

        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  contentContainer: {
    alignItems: 'center',
    maxWidth: 600,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  textContainer: {
    alignSelf: 'stretch',
  },
  header: {
    fontSize: 35,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  header1: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  info: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'center',
  },
  info1: {
    fontSize: 20,
    alignSelf: 'flex-start',
    textAlign: 'left',

  },
  about: {
    fontSize: 20,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
   projectsContainer: {
    alignSelf: 'stretch',
    marginTop: 20,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  projectImage: {
    width: 300,
    height: 300,
    marginBottom: 10,
    alignSelf: 'center',
  },
  projectLink: {
    fontSize: 16,
    marginBottom: 5,
    textAlign: 'center',
  },
  projectDescription: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'justify',
  },


});

export default App;
